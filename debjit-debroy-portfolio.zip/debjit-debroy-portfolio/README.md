# Debjit Debroy — Wedding Photography

A dark, cinematic 3D creator portfolio landing page built with **React + TypeScript + Vite**, styled with **Tailwind CSS**, animated with **Framer Motion**, and iconography from **Lucide React**.

## Getting started

```bash
npm install
npm run dev      # start the dev server (http://localhost:5173)
npm run build    # type-check + production build into /dist
npm run preview  # preview the production build
```

> Node 18+ is recommended.

## Sections

1. **Hero** — full-viewport nav, massive gradient wordmark, tagline + CTA, and a mouse-following magnetic portrait.
2. **Marquee** — two rows of wedding photos that drift in opposite directions based on scroll position.
3. **About** — gradient "The Artist" heading, decorative corner icons, and a character-by-character scroll-reveal paragraph.
4. **Services** — white panel with a numbered "Expertise" list.
5. **Albums** — sticky card stack of three project albums that scale down as you scroll past them.

## Project structure

```
src/
├── App.tsx                 # composes the five sections
├── main.tsx                # React entry
├── index.css               # reset, Kanit font, .hero-heading gradient
├── data/
│   └── content.ts          # image URLs + album/service copy
└── components/
    ├── HeroSection.tsx
    ├── MarqueeSection.tsx
    ├── AboutSection.tsx
    ├── ServicesSection.tsx
    ├── AlbumsSection.tsx
    ├── ContactButton.tsx       # gradient "Book a Session" pill
    ├── LiveProjectButton.tsx   # ghost "View Album" pill
    ├── FadeIn.tsx              # whileInView reveal wrapper
    ├── Magnet.tsx             # magnetic hover effect
    └── AnimatedText.tsx       # scroll-driven char reveal
```

## Theming notes

- Background `#0C0C0C`, accent gold gradient `#E6D089 → #B8904D`, light text `#D7E2EA`.
- Font: **Kanit** (Google Fonts, weights 300–900), loaded in `index.html`.
- Heavy use of `clamp()` for fluid typography; mobile-first across Tailwind's `sm`/`md`/`lg` breakpoints.

All photography is sourced from Unsplash via hotlinked URLs — swap them in `src/data/content.ts` and `src/components/HeroSection.tsx` to use your own work.
