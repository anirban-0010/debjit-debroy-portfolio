// ---- Marquee images (21 total) ----
// Row 1 uses the first 11, Row 2 uses the remaining 10.
export const marqueeImages: string[] = [
  'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1606800052052-a08af7148866?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1520854221256-17451cc331bf?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1542031835-2ee87bd1f964?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1532712938730-4e36c457b9c7?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1511895426328-dc8714191300?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1606490206148-1fb70163351b?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1583939411023-14783179e581?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1529636798458-92182e662485?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1550005809-91ad75fb315f?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1621888806296-6e27ab0d6ccb?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1530103862676-de3c9da59c3b?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=800&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1475714622877-641e013c6096?q=80&w=800&auto=format&fit=crop',
];

// ---- Albums ----
export interface Album {
  num: string;
  name: string;
  category: string;
  col1: [string, string];
  col2: string;
}

export const albums: Album[] = [
  {
    num: '01',
    name: 'Priyanka & Rahul',
    category: 'Traditional Bengali Wedding',
    col1: [
      'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1280&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1606800052052-a08af7148866?q=80&w=1280&auto=format&fit=crop',
    ],
    col2:
      'https://images.unsplash.com/photo-1532712938730-4e36c457b9c7?q=80&w=1280&auto=format&fit=crop',
  },
  {
    num: '02',
    name: 'Sneha & Arjun',
    category: 'Destination Wedding in Jaipur',
    col1: [
      'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1280&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1542031835-2ee87bd1f964?q=80&w=1280&auto=format&fit=crop',
    ],
    col2:
      'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=1280&auto=format&fit=crop',
  },
  {
    num: '03',
    name: 'Aarti & Karan',
    category: 'Intimate Pre-Wedding',
    col1: [
      'https://images.unsplash.com/photo-1621888806296-6e27ab0d6ccb?q=80&w=1280&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1511895426328-dc8714191300?q=80&w=1280&auto=format&fit=crop',
    ],
    col2:
      'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?q=80&w=1280&auto=format&fit=crop',
  },
];

// ---- Services ----
export interface Service {
  num: string;
  name: string;
  desc: string;
}

export const services: Service[] = [
  {
    num: '01',
    name: 'Pre-Wedding Shoots',
    desc: 'Capturing your unique chemistry and love story in breathtaking locations before the chaos of the big day begins.',
  },
  {
    num: '02',
    name: 'Candid Photography',
    desc: 'Unobtrusive, natural shots that immortalize the raw emotions, fleeting laughter, and happy tears of your celebration.',
  },
  {
    num: '03',
    name: 'Cinematic Videography',
    desc: 'Story-driven, beautifully color-graded wedding films that allow you to relive your special day like a movie.',
  },
  {
    num: '04',
    name: 'Traditional Photography',
    desc: 'Classic, timeless portraits and essential family group shots that form the foundation of every Indian wedding album.',
  },
  {
    num: '05',
    name: 'Albums & Prints',
    desc: 'Premium, custom-designed photo books printed on museum-grade archival paper to preserve your legacy for generations.',
  },
];
