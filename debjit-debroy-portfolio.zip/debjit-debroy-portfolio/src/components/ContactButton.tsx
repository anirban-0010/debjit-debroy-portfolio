interface ContactButtonProps {
  className?: string;
  label?: string;
}

export default function ContactButton({
  className = '',
  label = 'Book a Session',
}: ContactButtonProps) {
  return (
    <button
      type="button"
      className={`rounded-full text-white font-medium uppercase tracking-widest px-8 py-3 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base ${className}`}
      style={{
        background:
          'linear-gradient(123deg, #4A3C15 7%, #B8904D 37%, #E6D089 72%, #7A5C24 100%)',
        boxShadow:
          '0px 4px 4px rgba(184, 144, 77, 0.25), 4px 4px 12px #4A3C15 inset',
        outline: '2px solid #FFFFFF',
        outlineOffset: '-3px',
      }}
    >
      {label}
    </button>
  );
}
