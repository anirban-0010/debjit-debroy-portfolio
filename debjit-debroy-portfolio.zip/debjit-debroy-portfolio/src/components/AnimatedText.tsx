import { type CSSProperties, Fragment, useRef } from 'react';
import {
  motion,
  type MotionValue,
  useScroll,
  useTransform,
} from 'framer-motion';

interface AnimatedTextProps {
  text: string;
  className?: string;
  style?: CSSProperties;
}

interface CharProps {
  children: string;
  progress: MotionValue<number>;
  range: [number, number];
}

function Char({ children, progress, range }: CharProps) {
  const opacity = useTransform(progress, range, [0.2, 1]);
  return (
    <span style={{ position: 'relative', display: 'inline-block' }}>
      {/* Invisible placeholder reserves the layout space */}
      <span style={{ opacity: 0 }}>{children}</span>
      {/* Animated copy sits on top, fading 0.2 -> 1 with scroll */}
      <motion.span style={{ position: 'absolute', left: 0, top: 0, opacity }}>
        {children}
      </motion.span>
    </span>
  );
}

export default function AnimatedText({ text, className, style }: AnimatedTextProps) {
  const ref = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start 0.8', 'end 0.2'],
  });

  const words = text.split(' ');
  const total = text.length;
  let counter = 0;

  return (
    <p ref={ref} className={className} style={style}>
      {words.map((word, wi) => {
        const wordStart = counter;
        // account for the space that follows each word
        counter += word.length + 1;
        return (
          <Fragment key={wi}>
            <span style={{ display: 'inline-block' }}>
              {word.split('').map((ch, ci) => {
                const i = wordStart + ci;
                return (
                  <Char
                    key={ci}
                    progress={scrollYProgress}
                    range={[i / total, (i + 1) / total]}
                  >
                    {ch}
                  </Char>
                );
              })}
            </span>
            {wi < words.length - 1 ? ' ' : ''}
          </Fragment>
        );
      })}
    </p>
  );
}
