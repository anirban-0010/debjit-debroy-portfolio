import { useRef } from 'react';
import { motion, type MotionValue, useScroll, useTransform } from 'framer-motion';
import FadeIn from './FadeIn';
import LiveProjectButton from './LiveProjectButton';
import { albums, type Album } from '../data/content';

interface CardProps {
  album: Album;
  index: number;
  progress: MotionValue<number>;
  range: [number, number];
  targetScale: number;
}

function Card({ album, index, progress, range, targetScale }: CardProps) {
  const scale = useTransform(progress, range, [1, targetScale]);

  return (
    <div className="h-[85vh] flex items-start justify-center sticky top-24 md:top-32">
      <motion.div
        style={{ scale, top: `${index * 28}px` }}
        className="relative w-full origin-top rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border-2 border-[#D7E2EA] bg-[#0C0C0C] p-4 sm:p-6 md:p-8"
      >
        {/* Top row */}
        <div className="flex items-center justify-between gap-4 flex-wrap mb-4 sm:mb-6 md:mb-8">
          <div className="flex items-center gap-4 sm:gap-6">
            <span
              className="hero-heading font-black"
              style={{ fontSize: 'clamp(3rem, 10vw, 140px)', lineHeight: 1 }}
            >
              {album.num}
            </span>
            <div className="flex flex-col">
              <span className="text-[#E6D089] uppercase tracking-widest text-xs sm:text-sm">
                {album.category}
              </span>
              <span
                className="text-[#D7E2EA] font-medium uppercase"
                style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)', lineHeight: 1.1 }}
              >
                {album.name}
              </span>
            </div>
          </div>

          <LiveProjectButton />
        </div>

        {/* Bottom row: 40 / 60 image grid */}
        <div className="flex gap-3 sm:gap-4 md:gap-5">
          <div
            className="flex flex-col gap-3 sm:gap-4 md:gap-5"
            style={{ width: '40%' }}
          >
            <img
              src={album.col1[0]}
              loading="lazy"
              alt={`${album.name} — 1`}
              className="w-full object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"
              style={{ height: 'clamp(130px, 16vw, 230px)' }}
            />
            <img
              src={album.col1[1]}
              loading="lazy"
              alt={`${album.name} — 2`}
              className="w-full object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"
              style={{ height: 'clamp(160px, 22vw, 340px)' }}
            />
          </div>

          <div style={{ width: '60%' }}>
            <img
              src={album.col2}
              loading="lazy"
              alt={`${album.name} — 3`}
              className="w-full h-full object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function AlbumsSection() {
  const container = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end end'],
  });

  return (
    <section
      id="albums"
      className="bg-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] -mt-10 sm:-mt-12 md:-mt-14 relative z-10 px-5 sm:px-8 md:px-10 pt-24 sm:pt-28 md:pt-32 pb-20"
    >
      <FadeIn y={40} className="w-full text-center">
        <h2
          className="hero-heading font-black uppercase leading-none tracking-tight"
          style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
        >
          Album
        </h2>
      </FadeIn>

      <div ref={container} className="mt-12 sm:mt-16 md:mt-20">
        {albums.map((album, i) => {
          const targetScale = 1 - (albums.length - 1 - i) * 0.03;
          return (
            <Card
              key={album.num}
              album={album}
              index={i}
              progress={scrollYProgress}
              range={[i / albums.length, 1]}
              targetScale={targetScale}
            />
          );
        })}
      </div>
    </section>
  );
}
