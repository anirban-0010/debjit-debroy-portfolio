import { Camera, HeartHandshake, Video, Image as ImageIcon } from 'lucide-react';
import FadeIn from './FadeIn';
import AnimatedText from './AnimatedText';
import ContactButton from './ContactButton';

const ABOUT_TEXT =
  "With over a decade of experience deeply rooted in Kolkata's rich culture, I focus on candid moments, cinematic storytelling, and authentic emotions. I truly enjoy working with couples who want to document their special day in its truest, most beautiful form. Let's capture your legacy together.";

const iconColor = { color: '#E6D089', opacity: 0.2 };

export default function AboutSection() {
  return (
    <section
      id="about"
      className="relative min-h-screen flex items-center justify-center px-5 sm:px-8 md:px-10 py-20 overflow-hidden bg-[#0C0C0C]"
    >
      {/* Decorative corner icons */}
      <FadeIn
        delay={0.1}
        x={-80}
        y={0}
        duration={0.9}
        className="absolute top-[4%] left-[1%] sm:left-[2%] md:left-[4%] z-0"
      >
        <Camera
          className="w-[120px] sm:w-[160px] md:w-[210px] h-auto"
          style={iconColor}
          strokeWidth={1}
        />
      </FadeIn>

      <FadeIn
        delay={0.25}
        x={-80}
        y={0}
        duration={0.9}
        className="absolute bottom-[8%] left-[3%] sm:left-[6%] md:left-[10%] z-0"
      >
        <HeartHandshake
          className="w-[100px] sm:w-[140px] md:w-[180px] h-auto"
          style={iconColor}
          strokeWidth={1}
        />
      </FadeIn>

      <FadeIn
        delay={0.15}
        x={80}
        y={0}
        duration={0.9}
        className="absolute top-[4%] right-[1%] sm:right-[2%] md:right-[4%] z-0"
      >
        <Video
          className="w-[120px] sm:w-[160px] md:w-[210px] h-auto"
          style={iconColor}
          strokeWidth={1}
        />
      </FadeIn>

      <FadeIn
        delay={0.3}
        x={80}
        y={0}
        duration={0.9}
        className="absolute bottom-[8%] right-[3%] sm:right-[6%] md:right-[10%] z-0"
      >
        <ImageIcon
          className="w-[130px] sm:w-[170px] md:w-[220px] h-auto"
          style={iconColor}
          strokeWidth={1}
        />
      </FadeIn>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-16 sm:gap-20 md:gap-24 w-full">
        <div className="flex flex-col items-center gap-10 sm:gap-14 md:gap-16 w-full">
          <FadeIn y={40} className="w-full text-center">
            <h2
              className="hero-heading font-black uppercase leading-none tracking-tight"
              style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
            >
              The Artist
            </h2>
          </FadeIn>

          <AnimatedText
            text={ABOUT_TEXT}
            className="text-[#D7E2EA] font-medium text-center leading-relaxed max-w-[560px]"
            style={{ fontSize: 'clamp(1rem, 2vw, 1.35rem)' }}
          />
        </div>

        <FadeIn delay={0.1} y={20}>
          <ContactButton />
        </FadeIn>
      </div>
    </section>
  );
}
