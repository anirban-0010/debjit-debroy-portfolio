import { useEffect, useRef, useState } from 'react';
import { marqueeImages } from '../data/content';

function Tile({ src }: { src: string }) {
  return (
    <img
      src={src}
      loading="lazy"
      alt="Wedding photography"
      className="rounded-2xl object-cover grayscale hover:grayscale-0 transition-all duration-500 flex-shrink-0"
      style={{ width: 420, height: 270 }}
    />
  );
}

const triple = (arr: string[]) => [...arr, ...arr, ...arr];

export default function MarqueeSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const el = sectionRef.current;
      if (!el) return;
      const sectionTop = el.offsetTop;
      const value =
        (window.scrollY - sectionTop + window.innerHeight) * 0.3;
      setOffset(value);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const row1 = triple(marqueeImages.slice(0, 11));
  const row2 = triple(marqueeImages.slice(11));

  return (
    <section
      ref={sectionRef}
      className="bg-[#0C0C0C] pt-24 sm:pt-32 md:pt-40 pb-10"
      style={{ overflowX: 'clip' }}
    >
      <div className="flex flex-col gap-3">
        {/* Row 1 — drifts right as you scroll */}
        <div
          className="flex gap-3"
          style={{
            transform: `translateX(${offset - 200}px)`,
            willChange: 'transform',
          }}
        >
          {row1.map((src, i) => (
            <Tile key={`r1-${i}`} src={src} />
          ))}
        </div>

        {/* Row 2 — drifts left as you scroll */}
        <div
          className="flex gap-3"
          style={{
            transform: `translateX(${-(offset - 200)}px)`,
            willChange: 'transform',
          }}
        >
          {row2.map((src, i) => (
            <Tile key={`r2-${i}`} src={src} />
          ))}
        </div>
      </div>
    </section>
  );
}
